﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using static ConsoleApp1.Program;
using System.Collections;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleApp1
{
    internal class Program
    {
        [DllImport("kernel32.dll")]
        public static extern IntPtr LoadLibrary(string dllToLoad);

        [DllImport("kernel32.dll")]
        public static extern IntPtr GetProcAddress(IntPtr hModule, string procedureName);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate bool moveDelegate();
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void startDelegate();
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void answerDelegate(bool n);

        static void module(string str, ref moveDelegate move, ref answerDelegate answer, ref startDelegate start)
        {
            IntPtr module = LoadLibrary(str);
            IntPtr address_move = GetProcAddress(module, "move");
            move = (moveDelegate)Marshal.GetDelegateForFunctionPointer(address_move, typeof(moveDelegate));
            IntPtr address_answer = GetProcAddress(module, "answer");
            answer = (answerDelegate)Marshal.GetDelegateForFunctionPointer(address_answer, typeof(answerDelegate));
            IntPtr address_start = GetProcAddress(module, "start");
            start = (startDelegate)Marshal.GetDelegateForFunctionPointer(address_start, typeof(startDelegate));
        }

        static void random_files(ref string[] files)
        {
            Random random = new Random();
            files = files.OrderBy(x => random.Next()).ToArray();
        }

        static void dop(bool n)
        {
            if (n)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("C");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("П");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }

        static void write(bool[] player_1, bool[] player_2)
        {
            for (int i = 0; i < player_1.Length; i++)
            {
                dop(player_1[i]);
            }
            Console.WriteLine();
            for (int i = 0; i < player_2.Length; i++)
            {
                dop(player_2[i]);
            }
            Console.WriteLine();
        }
        static void consignment(bool player_1, bool player_2, ref int glasses_1, ref int glasses_2)
        {
            if (player_1 && player_2)
            {
                glasses_1 += 3;
                glasses_2 += 3;
            }
            else
            {
                if (player_1 || player_2)
                {
                    glasses_1 += Convert.ToInt16(!player_1) * 5;
                    glasses_2 += Convert.ToInt16(!player_2) * 5;
                }
                else
                {
                    glasses_1 += 1;
                    glasses_2 += 1;
                }
            }
        }
        public static Dictionary<string, long> SortDictionaryByValue(Dictionary<string, long> stragies)
        {
            // Сортируем словарь по убыванию значений
            var sortedStragies = stragies.OrderByDescending(x => x.Value)
                                        .ToDictionary(x => x.Key, x => x.Value);

            return sortedStragies;
        }
        static void Main(string[] args)
        {
            int tyr_count = 0;
            do {
                do
                {
                    Console.WriteLine("Количество туров");
                } while (!int.TryParse(Console.ReadLine(), out tyr_count) && tyr_count <= 0);
            }while(tyr_count <= 0);

            bool noise = false;
            int frequency = 0;
            do
            {
                Console.WriteLine("Включить шум");
            } while (!bool.TryParse(Console.ReadLine(), out noise));
            if (noise)
            {
                do {
                    do
                    {
                        Console.WriteLine("Частота шума");
                    } while ((!int.TryParse(Console.ReadLine(), out frequency)));
                }while(!(frequency > 1 && frequency < 99));
                frequency = 100 - frequency;
            }

            bool paint_party = true;
            do
            {
                Console.WriteLine("Включить отрисовку партий");
            } while (!bool.TryParse(Console.ReadLine(), out paint_party));

            bool rendering_everything = true;
            int number_strag = 0;
            if (paint_party)
            {
                do
                {
                    Console.WriteLine("Отрисовать все стратегии");
                } while (!bool.TryParse(Console.ReadLine(), out rendering_everything));
            }

            Random rnd = new Random();
            int randomNumber = rnd.Next(-5, 5);
            int noise_random = rnd.Next(0, 1);
            int n = 200 + randomNumber;
            bool[] player_1 = new bool[n];
            bool[] player_2 = new bool[n];
            Dictionary<string, long> stragies_through = new Dictionary<string, long>();
            Dictionary<string, long> stragies_count = new Dictionary<string, long>();
            Dictionary<string, long> stragies_stage = new Dictionary<string, long>();
            int player_1_glasses = 0, player_2_glasses = 0;
            string[] files = Directory.GetFiles("strategies");

            if (!rendering_everything)
            {
                int count = 0;
                foreach(var stragies in files)
                {
                    Console.WriteLine(count + " " + stragies);
                    count++;
                }
                do
                {
                    Console.WriteLine("Номер стратегии для отрисовки");
                } while (!int.TryParse(Console.ReadLine(), out number_strag) && number_strag > -1 && number_strag <= count);
            }
            string rendering_stragies = files[number_strag];

            foreach (string file in files)
            {
                stragies_through.Add(file, 0);
                stragies_count.Add(file, 0);
                stragies_stage.Add(file, 0);
            }
            int size = files.Length;

            for (int tyr = 0; tyr < tyr_count; tyr++)
            {
                random_files(ref files);
                for (int p1 = 0; p1 < size; p1++)
                {
                    string str1 = files[p1].ToString();
                    moveDelegate move1 = null;
                    answerDelegate answer1 = null;
                    startDelegate start1 = null;
                    module(str1, ref move1, ref answer1, ref start1);

                    for (int p2 = p1; p2 < size; p2++)
                    {
                        string str2 = files[p2].ToString();
                        if(str1 == str2) str2 = str2.Replace("strategies", "strategies_copy");
                        moveDelegate move2 = null;
                        answerDelegate answer2 = null;
                        startDelegate start2 = null;
                        module(str2, ref move2, ref answer2, ref start2);

                        start1();
                        start2();

                        for (int i = 0; i < n; i++)
                        {
                            player_1[i] = move1();
                            player_2[i] = move2();
                            consignment(player_1[i], player_2[i], ref player_1_glasses, ref player_2_glasses);
                            if (noise)
                            {
                                noise_random = rnd.Next(-1, 2);
                                if (i % (frequency + noise_random) == 0 && i != 0)
                                {
                                    noise_random = rnd.Next(1, 3);
                                    if (noise_random == 1)
                                    { answer1(player_2[i]); answer2(!player_1[i]); }
                                    else
                                    { answer1(!player_2[i]); answer2(player_1[i]); }
                                }
                                else
                                { answer1(player_2[i]); answer2(player_1[i]); }
                            }
                            else
                            { answer1(player_2[i]); answer2(player_1[i]); }
                        }

                        str2 = str2.Replace("strategies_copy", "strategies");
                        if (str1 != str2)
                        {
                            stragies_through[str1] += player_1_glasses;
                            stragies_through[str2] += player_2_glasses;
                            stragies_stage[str1] += player_1_glasses;
                            stragies_stage[str2] += player_2_glasses;
                        }
                        else
                        {
                            stragies_stage[str1] += player_1_glasses;
                            stragies_through[str1] += player_1_glasses;
                        }

                        if (paint_party)
                        {
                            if (!rendering_everything)
                            {
                                if (str1 == rendering_stragies || str2 == rendering_stragies)
                                {
                                    Console.WriteLine(str1 + " " + str2);
                                    Console.WriteLine(player_1_glasses + " " + player_2_glasses);
                                    write(player_1, player_2);
                                }
                            }
                            else
                            {
                                Console.WriteLine(str1 + " " + str2);
                                Console.WriteLine(player_1_glasses + " " + player_2_glasses);
                                write(player_1, player_2);
                            }
                        }

                        player_1_glasses = 0;
                        player_2_glasses = 0;
                    }
                }
                Console.WriteLine();
                stragies_through = SortDictionaryByValue(stragies_through);
                stragies_stage = SortDictionaryByValue(stragies_stage);


                for (int i = 0; i < stragies_stage.Count(); i++)
                    stragies_count[stragies_stage.Keys.ToList()[i]] += stragies_stage.Count() - i;
                for (int i = 0; i < stragies_stage.Count(); i++)
                    stragies_stage[stragies_stage.Keys.ToList()[i]] = 0;

                int count = 1;
                foreach (var strag in stragies_through)
                {
                    Console.WriteLine(count + "[" + $"стратегия: {strag.Key}  очки: {strag.Value} баллы: {stragies_count[strag.Key]}");
                    count++;
                }
                for (int k = 0; k < (n * Convert.ToInt32(paint_party)); k++)
                {
                    Console.Write("-");
                }
                Console.WriteLine();
            }
            using (StreamWriter sw = new StreamWriter("отчёт.txt", true))
            {
                sw.WriteLine("[" + tyr_count + " " + noise + "(" + ((100 - frequency) * Convert.ToInt32(noise)) + ") " + DateTime.Now + "]");
                int count = 1;
                foreach (var strag in stragies_through)
                {
                    sw.WriteLine(count + "[" + $"стратегия: {strag.Key}  очки: {strag.Value} баллы: {stragies_count[strag.Key]}");
                    count++;
                }
                sw.WriteLine();
            }
            Console.ReadKey();
        }
    }
}

